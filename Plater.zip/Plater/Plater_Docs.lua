
local _

do 
	
	PlaterDocs = {}
	
	PlaterDocs.UnitFrame = {
		
		childs = {
			
		},
		
		members = {
			
		},
		
		info = {
			desc = "parent of all components that make up the nameplate.",
			parent = "plateFrame",
			type = "button",
		},
	
	}
end