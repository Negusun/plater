@Terciob:
- Work on next feature: personal resources.

@cont1nuity:
- Limit 'View Distance' settings according to client limitations.
- Only show cast colors if they are enabled.
- Fixing issues with combo points in classic era (feature in development).
- Fixing missing cast name in classic era.
- NPC-Cache entries will be kept on profile export if NPC-Colors are assigned.

