# LibClassicCasterino

## [1.20](https://github.com/rgd87/LibClassicCasterino/tree/1.20) (2019-10-03)
[Full Changelog](https://github.com/rgd87/LibClassicCasterino/compare/1.16...1.20)

- Added Mage's Teleports and Portals  
- Aimed Shot for player  
- Bump Minor  
- Merge pull request #15 from siweia/patch-1  
    Fix castbar visibility when unit is player itself  
- Fix castbar visibility when unit is player itself  
- Changed fallback icon  
- UNIT\_SPELLCAST\_SUCCEEDED passthrough  
