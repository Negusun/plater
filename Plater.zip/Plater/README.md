# Plater-Nameplates
Source code for World of Warcraft addon Plater Nameplates.

General Frequent Asked Questions:
https://www.curseforge.com/wow/addons/plater-nameplates/pages/faq

General Scripting Guide:
https://www.curseforge.com/wow/addons/plater-nameplates/pages/scripts


The Wago.io logo was graciously provided for use within Plater by the owner and creator of Wago.io (Oratory).
