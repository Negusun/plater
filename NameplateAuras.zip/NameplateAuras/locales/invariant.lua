local L = LibStub("AceLocale-3.0"):GetLocale("NameplateAuras"); -- luacheck: ignore
L["options:apps:explosive-orbs"] = GetSpellInfo(240446); -- luacheck: ignore